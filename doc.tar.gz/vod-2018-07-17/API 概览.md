## 媒体管理相关接口

| 接口名称 | 接口功能 | 频率限制（次/秒） |
|-|-|-|
| [ModifyMediaStorageClass](/document/api/266/70862) | 修改媒体文件存储类型 | 20 |
| [RestoreMedia](/document/api/266/75728) | 解冻媒体文件 | 20 |

